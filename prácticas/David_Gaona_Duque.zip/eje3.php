<?php

define ("N",5);
$Silla = array();

function Generar_Matriz(&$Vector) {
    for($f = 0; $f < N; $f++) {
        for($c = 0; $c < N; $c++) {
            $Vector[$f][$c] = rand(1,50);
        }
    }

    for($f = 0; $f <N; $f++) {
        for($c = 0; $c < N; $c++) {
            echo $Vector[$f][$c],",";
        }
        echo "<br>";
    }
}

function Mayor_Fila(&$Vector) {
    for($f = 0; $f < N; $f++) { 
        echo max($Vector[$f]),",";
    }
}

function Menor_Columna(&$Vector) {
    $Menor = 50;
    for($f = 0; $f < N; $f++) {
        for($c = 0; $c < N; $c++) {
            if($Vector[$c][$f] < $Menor) {
                $Menor = $Vector[$c][$f];
            }
        }
        echo $Menor,",";
        $Menor = 50;
    }
    
}
echo "El vector generado aleatoriamente es <br>", Generar_Matriz($Silla), "<br>"; 

echo "El mayor de cada fila es ", Mayor_Fila($Silla), "<br>";

echo "El menor de cada columna es ", Menor_Columna($Silla), "<br>";
?>