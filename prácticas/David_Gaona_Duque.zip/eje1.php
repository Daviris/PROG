<?php

define("N",5);
$Array = array(N);

function Generar_Vector(&$Vector) {
    for($i = 0; $i < N; $i++) {
        $Vector[$i] = rand(1,20);
    }

    for($i = 0; $i < N; $i++) {
        echo $Vector[$i],",";
    }
}

function Suma_Pares($Vector) {
    $Suma = 0;
    for($i = 0; $i < N; $i++) {
        if($Vector[$i] % 2 == 0) {
            $Suma += $Vector[$i];
        }
    }
    return $Suma;
}

function Mostrar_Pares(&$Vector) {
    for($i = 0; $i < N; $i++) {
        if($Vector[$i] % 2 == 0) {
            echo $Vector[$i],",";
        }
    }
}

function Calcular_Media($Suma) {
    $Media = $Suma / N;
    return $Media;
}

echo "El array generado aleatoriamente es ", Generar_Vector($Array),"<br>";

echo "Los numeros pares del array son los siguientes ", Mostrar_Pares($Array),"<br>";

echo "La suma de todos los numeros pares anteriores es de ", Suma_Pares($Array),"<br>";

echo "Y por último, la media de la suma de estos pares es ", Calcular_Media(Suma_Pares($Array)), "<br";