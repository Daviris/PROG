<?php

$A = rand(2,50);
$B = rand(2,5);

function Elevado($A, $B) {
    $a = $A;

    while ($B > 1) {
        $A *= $a;
        $B--;
    }
    return $A;
}

echo "$A elevado a $B es ", Elevado($A, $B), "<br>";