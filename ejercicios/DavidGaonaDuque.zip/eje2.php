<?php

function buscarnumero($Fichero) {

}

$Fichero = fopen("Fichero1.txt","r");
$Fichero1 = fopen("f1.txt","w+");
$Fichero2 = fopen("f2.txt","w+");

while(feof($Fichero) == FALSE) {
    $Lineas = fgets($Fichero);
    if(strstr($Lineas,1) || strstr($Lineas,2)){
        fwrite($Fichero1,$Lineas);
        echo "<br> Contiene un número <br>";
    } else{
        fwrite($Fichero2,$Lineas);
        echo "<br> No contiene ningún número <br>";
    }
}

fclose($Fichero);
fclose($Fichero1);
fclose($Fichero2);

?>