<?php

$Fichero2 = fopen("Fichero2.txt","r");
$Fichero3 = fopen("Fichero3.txt","r");
$Fichero4 = fopen("Fichero4.txt","w+");
$Ordenado = array();

while(feof($Fichero2) == FALSE){
    for($i = 0; $i < 6; $i++){
        $Ordenado[$i] = fgets($Fichero2);
    }
}

while(feof($Fichero3) == FALSE){
    for($i = 7; $i < 15; $i++){
        $Ordenado[$i] = fgets($Fichero3);
    }
}

sort($Ordenado);
var_dump($Ordenado);

for($i = 0; $i < 14; $i++) {
    fwrite($Fichero4,$Ordenado[$i]);
}


fclose($Fichero2);
fclose($Fichero3);
fclose($Fichero4);

?>