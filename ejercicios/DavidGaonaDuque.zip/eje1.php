<?php

$Fichero = fopen("Fichero.txt","r+");
$FicheroCasa = fopen("Ficherocasa.txt","w+");
$Casa = 0;

while(feof($Fichero) == FALSE) {
    $Lineas = fgets($Fichero);
    if(strstr($Lineas,"casa")) {
         $Casa++;
    }
}

$Resultado = "Casa, $Casa";

fwrite($FicheroCasa,$Resultado);
fwrite($FicheroCasa,"\n");

rewind($Fichero);

while(feof($Fichero) == FALSE) {
    $Lineas = fgets($Fichero);
    fwrite($FicheroCasa,$Lineas);
}

fclose($Fichero);
fclose($FicheroCasa);

?>